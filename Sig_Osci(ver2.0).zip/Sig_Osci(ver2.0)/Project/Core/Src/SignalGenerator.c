#include "SignalGenerator.h"

void Sig_Init(void)//信号发生器初始化
{
	Sig_WaveGene_TableCalcu();//计算波形表
	Sig_UI_Init();//菜单初始化
}

void Sig_Start(void)
{
	Sig_WaveGene_Start();
}

void Sig_Handle(void)//信号发生器任务处理函数，放在主函数循环里，可添加任务管理器模块平衡信号发生器和示波器任务之间的资源占用
{
	Sig_UI_Select();
	Sig_UI_WaveConfig();
}