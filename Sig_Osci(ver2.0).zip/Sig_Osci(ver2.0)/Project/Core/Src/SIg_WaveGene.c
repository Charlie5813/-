#include "Sig_WaveGene.h"

Sig_SIGTYPE Sig_WaveGene_SigType;
float Sig_WaveGene_Amp=0;//幅值
float Sig_WaveGene_Freq=0;
float sin_table[TABLE_LENGTH];//存一个周期sin函数的值
float triangle_table[TABLE_LENGTH];//幅值：0~1，存一个周期（即两个零点之间的波形）
float square_table[TABLE_LENGTH];//幅值：0~1，占空比50%，存一个周期

void Sig_WaveGene_TableCalcu(void)//主程序运行开始之前需要运行此函数
{
	int i=0;
	float index=0;
	for(i=0;i<TABLE_LENGTH;i++)//正弦表
	{
		index = (float)i/(TABLE_LENGTH-1) * 2*PI;
		sin_table[i] = sinf(index);
	}
	for(i=0;i<TABLE_LENGTH;i++)//三角表
	{
		if(i<TABLE_LENGTH/2)
			triangle_table[i] = i/(TABLE_LENGTH/2.0);
		else if(i>=TABLE_LENGTH/2)
			triangle_table[i] = 1-(i-TABLE_LENGTH/2.0)/(TABLE_LENGTH/2.0);			
	}
	for(i=0;i<TABLE_LENGTH;i++)
	{
		if(i<TABLE_LENGTH/2)
			square_table[i] = 1;
		else if(i>=TABLE_LENGTH/2)
			square_table[i] = 0;			
	}	
}

void Sig_WaveGene_Start(void)
{
	HAL_TIM_Base_Start_IT(&hdds);//开启DDS
	HAL_TIM_PWM_Start(&hpwm,PWM_CHANNEL);//开启PWM->DAC
}

void Sig_WaveGene_loop(void)//放在定时器中断处理函数里
{
	float f_word;//频率控制字
	int index;
	static float p=0;
	f_word = (TABLE_LENGTH*Sig_WaveGene_Freq)/1e5;
	index = (int)p;
	
	switch(Sig_WaveGene_SigType)
	{
		case SIN:
			__HAL_TIM_SetCompare(&hpwm,PWM_CHANNEL,((sin_table[index]+1)*50)*Sig_WaveGene_Amp/3.3);
			break;
		case TRIANGLE:
			__HAL_TIM_SetCompare(&hpwm,PWM_CHANNEL,triangle_table[index]*100*Sig_WaveGene_Amp/3.3);		
			break;
		case SQUARE:
			__HAL_TIM_SetCompare(&hpwm,PWM_CHANNEL,square_table[index]*100*Sig_WaveGene_Amp/3.3);		
			break;			
		case DC:
			__HAL_TIM_SetCompare(&hpwm,PWM_CHANNEL,100*Sig_WaveGene_Amp/3.3);					
			break;
	}
	p = p + f_word;
	if(p>=TABLE_LENGTH)
		p = p - TABLE_LENGTH;
}
