#include "Key.h"

uint8_t Key_Num=0;//0代表未被按下，1、2、3...代表哪个按键
GPIO_PinState Key_State[3]={1,1,1};
GPIO_PinState Key_LastState[3]={1,1,1};

void Key_Start(void)
{
	HAL_TIM_Base_Start_IT(&hkey);
}

void Key_IsKey(void)
{
	if(Key_LastState[0]==1 && Key_State[0]==0)
		Key_Num=1;
	if(Key_LastState[1]==1 && Key_State[1]==0)
		Key_Num=2;
	if(Key_LastState[2]==1 && Key_State[2]==0)
		Key_Num=3;		
}

void Key_Scan(void)//放在定时器里扫描
{
	Key_LastState[0] = Key_State[0];
	Key_State[0] = HAL_GPIO_ReadPin(GPIOKEY1,GPIO_PIN_KEY1);
	Key_LastState[1] = Key_State[1];
	Key_State[1] = HAL_GPIO_ReadPin(GPIOKEY2,GPIO_PIN_KEY2);
	Key_LastState[2] = Key_State[2];
	Key_State[2] = HAL_GPIO_ReadPin(GPIOKEY3,GPIO_PIN_KEY3);	
	Key_IsKey();
}

uint8_t Key(void)
{
	uint8_t tmp=0;
	tmp = Key_Num;
	Key_Num = 0;
	return tmp;
}
