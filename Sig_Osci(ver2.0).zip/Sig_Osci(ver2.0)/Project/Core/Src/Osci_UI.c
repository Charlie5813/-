#include "Osci_UI.h"

uint8_t Osci_UI_Grid[Osci_UI_Grid_L][Osci_UI_Grid_H];//背景坐标
uint8_t Osci_UI_Selector;//0:x  1:y  2:触发模式  3：触发电平  4：RUN/STOP  5：YT/ROLL 
uint16_t Osci_UI_Lastcount,Osci_UI_Count;
uint16_t Osci_UI_CountMemo[6]={0,3,0,100,1,0};//记住光标移走前的count值
uint16_t Osci_UI_RemindFlag[6];

void Osci_UI_CalcuGrid(void)//程序运行前，运行此函数
{
	uint8_t i,j;
	for(i=0;i<Osci_UI_Grid_L;i++)//边框
	{
		Osci_UI_Grid[i][0] = 1;
		Osci_UI_Grid[i][Osci_UI_Grid_H-1] = 1;
	}
	for(j=0;j<Osci_UI_Grid_H;j++)
	{
		Osci_UI_Grid[0][j] = 1;
		Osci_UI_Grid[Osci_UI_Grid_L-1][j] = 1;
	}
	
	for(i=10;i<Osci_UI_Grid_L;i=i+10)//虚线
	{
		for(j=2;j<Osci_UI_Grid_H;j=j+2)
		{
			Osci_UI_Grid[i][j] = 1;
		}
	}
	for(j=10;j<Osci_UI_Grid_H;j=j+10)
	{
		for(i=2;i<Osci_UI_Grid_L;i=i+2)
		{
			Osci_UI_Grid[i][j] = 1;	
		}
	}	
}

void Osci_UI_ShowGrid(void)//显示背景坐标
{
	uint8_t i,j;
	for(i=0;i<Osci_UI_Grid_L;i++)
	{
		for(j=0;j<Osci_UI_Grid_H;j++)
		{
			if(Osci_UI_Grid[i][j])
				LCD_DrawPoint(i,j,WHITE);			
		}
	}
}

void Osci_UI_MenuInit(void)
{
	LCD_ShowString(c1,r1," x:   1 us",WHITE,BLACK,12,0);
	LCD_ShowChar(0,0,'>',YELLOW,BLACK,12,0);
	LCD_ShowString(c1,r2," y: 200 mV",WHITE,BLACK,12,0);
	LCD_ShowString(c2,r1,"Auto",WHITE,BLACK,12,0);
	LCD_ShowString(c2,r2,"1.00 V",WHITE,BLACK,12,0);
	LCD_ShowString(c3,r1,"RUN",WHITE,BLACK,12,0);
	LCD_ShowString(c3,r2,"Y-T",WHITE,BLACK,12,0);
}

void Osci_UI_Init(void)
{
	LCD_Init();
	Osci_UI_CalcuGrid();
	Osci_UI_ShowGrid();
  Osci_UI_MenuInit();
	Encoder_Start(hosci_UI_encoder);
}

uint16_t Osci_UI_Encoder_GetCounter(void)
{
	uint16_t count;
	count = Encoder_GetCounter(hosci_UI_encoder);
	return count;
}

void Osci_UI_Encoder_SetCounter(uint16_t count)//0~1000
{
	if(count>1000)
		count=1000;
	Encoder_SetCounter(hosci_UI_encoder,count);
}

void Osci_UI_MenuSelect(void)
{
	uint8_t KeyNum=0;
	KeyNum = Key();
	if(KeyNum == 1)
		Key_Num = 1;
	else if(KeyNum == 3)
		Key_Num = 3;
	if(KeyNum == 2)
	{
		Osci_UI_Selector = Osci_UI_Selector + 1;
		Osci_UI_Selector = Osci_UI_Selector % 6;
		Osci_UI_RemindFlag[Osci_UI_Selector] = 1;
	}
	if(KeyNum == 2)
	{
		switch(Osci_UI_Selector)
		{
			case 0://x
				LCD_ShowChar(0,0,'>',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,' ',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,' ',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,' ',YELLOW,BLACK,12,0);
				break;
			case 1://y
				LCD_ShowChar(0,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,'>',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,' ',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,' ',YELLOW,BLACK,12,0);
				break;
			case 2://y
				LCD_ShowChar(0,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,' ',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,'>',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,' ',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,' ',YELLOW,BLACK,12,0);
				break;
			case 3://y
				LCD_ShowChar(0,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,' ',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,'>',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,' ',YELLOW,BLACK,12,0);
				break;
			case 4://y
				LCD_ShowChar(0,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,' ',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,' ',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,'>',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,' ',YELLOW,BLACK,12,0);
				break;
			case 5://y
				LCD_ShowChar(0,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(0,12,' ',YELLOW,BLACK,12,0);	
				LCD_ShowChar(69,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(69,12,' ',YELLOW,BLACK,12,0);			
				LCD_ShowChar(124,0,' ',YELLOW,BLACK,12,0);
				LCD_ShowChar(124,12,'>',YELLOW,BLACK,12,0);
				break;
		}
	}
}

void Osci_UI_ShowTrigLine(void)
{
	uint8_t i;
	static uint8_t lastindex,index;
	uint16_t trig;
	trig = Osci_Wave_Trigger;
	lastindex = index;
	index = (uint8_t)(trig/(Osci_Wave_Y/10.0));
	if(index>=Osci_UI_Grid_H)
		index = Osci_UI_Grid_H-1;
	if(Osci_Wave_TrigMode == Auto)
	{
		for(i=0;i<Osci_UI_Grid_L;i+=2)//消除上一次触发线
		{
			if(Osci_UI_Grid[i][lastindex])
				LCD_DrawPoint(i,lastindex,WHITE);
			else
				LCD_DrawPoint(i,lastindex,BLACK);					
		}	
	}
	else
	{
		if(lastindex != index)
		{
			for(i=0;i<Osci_UI_Grid_L;i+=2)//消除上一次触发线
			{
				if(Osci_UI_Grid[i][lastindex])
					LCD_DrawPoint(i,lastindex,WHITE);
				else
					LCD_DrawPoint(i,lastindex,BLACK);					
			}
			for(i=0;i<Osci_UI_Grid_L;i+=2)//画线
			{
				LCD_DrawPoint(i,index,ORANGE);			
			}
		}
		else
		{
			for(i=0;i<Osci_UI_Grid_L;i+=2)//画线
			{
				LCD_DrawPoint(i,index,ORANGE);				
			}
		}
	}	
}

void Osci_UI_DisConfig(void)
{
	Osci_UI_Lastcount = Osci_UI_Count;
	Osci_UI_Count = Osci_UI_Encoder_GetCounter();
	if(Osci_UI_RemindFlag[Osci_UI_Selector])
	{
		Osci_UI_Count = Osci_UI_CountMemo[Osci_UI_Selector];
		Osci_UI_Encoder_SetCounter(Osci_UI_Count);
		Osci_UI_RemindFlag[Osci_UI_Selector] = 0;
	}
	switch(Osci_UI_Selector)
	{
		case 0://x
			if(Osci_UI_Count>=Osci_Wave_XLength && Osci_UI_Count<500)//上越界
			{
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(0);
			}
			else if(Osci_UI_Count>500)//下越界
			{
				Osci_UI_Count = Osci_Wave_XLength - 1;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);			
			}
			Osci_Wave_X = Osci_Wave_XVals[Osci_UI_Count];
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				if(Osci_Wave_X<1000)//显示
				{
					LCD_ShowIntNum(18,0,Osci_Wave_X,4,WHITE,BLACK,12);
					LCD_ShowString(48,0,"us",WHITE,BLACK,12,0);
				}
				else
				{
					LCD_ShowIntNum(18,0,Osci_Wave_X/1000,4,WHITE,BLACK,12);
					LCD_ShowString(48,0,"ms",WHITE,BLACK,12,0);				
				}			
			}
			break;
		case 1://y
			Osci_Wave_Y = (Osci_UI_Count+1)*50;
			if(Osci_Wave_Y<50 || Osci_Wave_Y>20000)//下越界
			{
				Osci_Wave_Y = 10000;
				Osci_UI_Count = 199;
				Osci_UI_Encoder_SetCounter(199);				
			}
			else if(Osci_Wave_Y>10000)//上越界
			{
				Osci_Wave_Y = 50;			
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(0);
			}
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				if(Osci_Wave_Y<1000)//显示
				{
					LCD_ShowIntNum(18,12,Osci_Wave_Y,4,WHITE,BLACK,12);
					LCD_ShowString(48,12,"mV",WHITE,BLACK,12,0);
				}
				else
				{
					LCD_ShowFloatNum1(18,12,Osci_Wave_Y/1000.0,3,WHITE,BLACK,12);
					LCD_ShowString(48,12," V",WHITE,BLACK,12,0);				
				}
			}
			break;
		case 2://触发模式
			if(Osci_UI_Count>=3 && Osci_UI_Count<500)//上越界
			{
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);
			}
			else if(Osci_UI_Count>500)//下越界
			{
				Osci_UI_Count = 2;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);			
			}
			Osci_Wave_TrigMode = Osci_UI_Count;
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				switch(Osci_Wave_TrigMode)
				{
					case Auto:
						LCD_ShowString(c2,r1,"Auto  ",WHITE,BLACK,12,0);
						break;
					case Normal:
						LCD_ShowString(c2,r1,"Normal",WHITE,BLACK,12,0);
						break;
					case Single:
						LCD_ShowString(c2,r1,"Single",WHITE,BLACK,12,0);
						break;
				}
			}
			break;
		case 3://触发电平
			Osci_Wave_Trigger = Osci_UI_Count * 10;
			if(Osci_Wave_Trigger>5000)//下越界
			{
				Osci_Wave_Trigger = 3300;
				Osci_UI_Count = 330;
				Osci_UI_Encoder_SetCounter(330);				
			}
			else if(Osci_Wave_Trigger>3300)//上越界
			{
				Osci_Wave_Trigger = 0;			
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(0);
			}
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				if(Osci_Wave_Trigger<1000)//显示
				{
					LCD_ShowIntNum(c2,12,Osci_Wave_Trigger,4,WHITE,BLACK,12);
					LCD_ShowString(99,12,"mV",WHITE,BLACK,12,0);
				}
				else
				{
					LCD_ShowFloatNum1(c2,12,Osci_Wave_Trigger/1000.0,3,WHITE,BLACK,12);
					LCD_ShowString(99,12," V",WHITE,BLACK,12,0);				
				}
			}
			break;
		case 4://RUN/STOP
			if(Osci_UI_Count>=2 && Osci_UI_Count<500)//上越界
			{
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);
			}
			else if(Osci_UI_Count>500)//下越界
			{
				Osci_UI_Count = 1;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);			
			}
			Osci_Wave_RunMode = Osci_UI_Count;
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				switch(Osci_Wave_RunMode)
				{
					case RUN:
						LCD_ShowString(c3,r1,"RUN ",WHITE,BLACK,12,0);
						break;
					case STOP:
						LCD_ShowString(c3,r1,"STOP",WHITE,BLACK,12,0);
						break;
				}			
			}
			break;
		case 5://Y-T/ROLL
			if(Osci_UI_Count>=2 && Osci_UI_Count<500)//上越界
			{
				Osci_UI_Count = 0;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);
			}
			else if(Osci_UI_Count>500)//下越界
			{
				Osci_UI_Count = 1;
				Osci_UI_Encoder_SetCounter(Osci_UI_Count);			
			}
			Osci_Wave_DisplayMode = Osci_UI_Count;
			if(Osci_UI_Lastcount != Osci_UI_Count)//有变化才显示
			{
				switch(Osci_Wave_DisplayMode)
				{
					case YT:
						LCD_ShowString(c3,r2,"Y-T ",WHITE,BLACK,12,0);
						break;
					case ROLL:
						LCD_ShowString(c3,r2,"ROLL",WHITE,BLACK,12,0);
						break;
				}			
			}
			break;
	}
	Osci_UI_CountMemo[Osci_UI_Selector] = Osci_UI_Count;
}
