#include "Encoder.h"

void Encoder_Start(TIM_HandleTypeDef hencoder)
{
	HAL_TIM_Encoder_Start(&hencoder,Encoder_CHANNEL_ALL);
}

uint16_t Encoder_GetCounter(TIM_HandleTypeDef hencoder)//0~1000
{
	uint16_t count;
	count = __HAL_TIM_GetCounter(&hencoder);
	return count;
}

void Encoder_SetCounter(TIM_HandleTypeDef hencoder,uint16_t count)//0~1000
{
	if(count>1000)
		count=1000;
	__HAL_TIM_SetCounter(&hencoder,count);
}
