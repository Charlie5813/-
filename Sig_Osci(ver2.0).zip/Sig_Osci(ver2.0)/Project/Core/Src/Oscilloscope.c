#include "Oscilloscope.h"

void Osci_Init(void)
{
	Osci_UI_Init();
}

void Osci_Start(void)
{
	Osci_Wave_Start();
}

void Osci_Handle(void)
{
	Osci_UI_MenuSelect();	
	Osci_UI_DisConfig();
	Osci_Wave_Process();
	Osci_UI_ShowTrigLine();
}
