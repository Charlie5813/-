#ifndef __KEY_H__
#define __KEY_H__

#include "gpio.h"
#include "tim.h"

#define hkey          htim5
#define GPIOKEY1      GPIOA
#define GPIOKEY2      GPIOA
#define GPIOKEY3      GPIOB
#define GPIO_PIN_KEY1 GPIO_PIN_10
#define GPIO_PIN_KEY2 GPIO_PIN_11
#define GPIO_PIN_KEY3 GPIO_PIN_15

extern uint8_t Key_Num;//0代表未被按下，1、2、3...代表哪个按键

void Key_Start(void);
void Key_Scan(void);//放在定时器里扫描
uint8_t Key(void);

#endif
