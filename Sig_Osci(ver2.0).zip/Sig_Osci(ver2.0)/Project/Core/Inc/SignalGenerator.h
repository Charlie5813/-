#ifndef __SIGNALGENERATOR_H__
#define __SIGNALGENERATOR_H__

#include "Sig_UI.h"
#include "Sig_WaveGene.h"

void Sig_Init(void);
void Sig_Start(void);
void Sig_Handle(void);

#endif
