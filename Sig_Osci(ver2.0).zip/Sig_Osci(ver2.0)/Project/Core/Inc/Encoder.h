#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "tim.h"

#define hencoder1            htim1
#define hencoder2            htim2
#define Encoder_CHANNEL_ALL  TIM_CHANNEL_ALL

void Encoder_Start(TIM_HandleTypeDef hencoder);
uint16_t Encoder_GetCounter(TIM_HandleTypeDef hencoder);//0~1000
void Encoder_SetCounter(TIM_HandleTypeDef hencoder,uint16_t count);//0~1000

#endif
