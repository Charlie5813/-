#ifndef __OSCILLOSCOPE_H__
#define __OSCILLOSCOPE_H__

#include "Osci_UI.h"
#include "Osci_Wave.h"

void Osci_Init(void);
void Osci_Start(void);
void Osci_Handle(void);

#endif
