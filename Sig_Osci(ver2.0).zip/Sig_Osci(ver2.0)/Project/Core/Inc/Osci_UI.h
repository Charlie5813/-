#ifndef __OSCI_UI_H__
#define __OSCI_UI_H__

#include "Key.h"
#include "Encoder.h"
#include "lcd.h"
#include "Oscilloscope.h"

#define Osci_UI_Grid_L 160
#define Osci_UI_Grid_H 101
#define r1 0
#define r2 12
#define c1 0
#define c2 75
#define c3 130
#define hosci_UI_encoder hencoder2

extern uint8_t Osci_UI_Selector;
extern uint8_t Osci_UI_Grid[Osci_UI_Grid_L][Osci_UI_Grid_H];//��������
extern uint16_t Osci_UI_CountMemo[6];

void Osci_UI_CalcuGrid(void);
void Osci_UI_ShowGrid(void);
void Osci_UI_Init(void);
void Osci_UI_MenuSelect(void);
void Osci_UI_ShowTrigLine(void);
void Osci_UI_DisConfig(void);
void Osci_UI_Encoder_SetCounter(uint16_t count);//0~1000

#endif
