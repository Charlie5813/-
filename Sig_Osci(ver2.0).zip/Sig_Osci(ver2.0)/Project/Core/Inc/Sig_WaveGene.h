#ifndef __SIG_WAVEGENE_H__
#define __SIG_WAVEGENE_H__

#include "tim.h"
#include "math.h"
#include "SignalGenerator.h"

#define hdds              htim4
#define hpwm              htim3
#define PWM_CHANNEL       TIM_CHANNEL_1
#define TABLE_LENGTH      1024
#define PI                3.1415926535897   

typedef enum
{
	SIN=0,
	TRIANGLE,
	SQUARE,
	DC
}Sig_SIGTYPE;//信号类型

extern Sig_SIGTYPE Sig_WaveGene_SigType;
extern float Sig_WaveGene_Amp;//幅值
extern float Sig_WaveGene_Freq;

void Sig_WaveGene_TableCalcu(void);//主程序运行开始之前需要运行此函数
void Sig_WaveGene_Start(void);
void Sig_WaveGene_loop(void);//放在定时器中断处理函数里

#endif
